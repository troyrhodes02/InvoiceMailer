#!/bin/bash
echo "Launching InvoiceMailer..."
cd "$(dirname "$0")"
chmod +x InvoiceMailerUI
./InvoiceMailerUI 